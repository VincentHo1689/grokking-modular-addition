import torch
import torch.nn as nn
from torch import Tensor
from einops import repeat, rearrange

class DecoderBlock(torch.nn.Module):
    def __init__(self, dim_model: int, n_heads: int, dropout: float = 0.1):
        super().__init__()
        
        self.self_attn = nn.MultiheadAttention(dim_model, n_heads, dropout=dropout)
        self.self_attn_norm = nn.LayerNorm(dim_model)
        self.dropout1 = nn.Dropout(dropout)
        
        self.ffn = nn.Sequential(
            nn.Linear(dim_model, dim_model * 4),
            nn.GELU(),
            nn.Linear(dim_model * 4, dim_model)
        )
        self.ffn_norm = nn.LayerNorm(dim_model)
        self.dropout2 = nn.Dropout(dropout)

    def forward(self, x: Tensor):
        attn_mask = torch.full(
            (len(x), len(x)), -float("Inf"), device=x.device, dtype=x.dtype
        )
        attn_mask = torch.triu(attn_mask, diagonal=1)

        a1, _ = self.self_attn(x, x, x, attn_mask=attn_mask)
        a1 = self.dropout1(a1)
        a1 = self.self_attn_norm(x + a1)

        a2 = self.ffn(a1)
        a2 = self.dropout2(a2)
        a2 = self.ffn_norm(a1 + a2)

        return a2

class Transformer_dropout(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_heads, num_layers, output_dim, seq_len, dropout: float = 0.1):
        super(Transformer_dropout, self).__init__()
        
        # 输入嵌入层
        self.embedding = nn.Linear(input_dim, hidden_dim)
        
        # 位置编码
        self.position_embedding = nn.Embedding(seq_len, hidden_dim)
        
        # Dropout 层
        self.dropout = nn.Dropout(dropout)

        # Decoder Block
        self.model = nn.Sequential(
            *[DecoderBlock(hidden_dim, num_heads, dropout=dropout) for _ in range(num_layers)],
            nn.LayerNorm(hidden_dim),
            nn.Linear(hidden_dim, output_dim)
        )
    
    def forward(self, x):
        # x: [batch_size, seq_len, p]
        batch_size, seq_len, p = x.shape

        # 嵌入层
        x = self.embedding(x)  # [batch_size, seq_len, hidden_dim]

        # 添加位置编码
        positions = repeat(torch.arange(seq_len, device=x.device), "p -> b p", b=batch_size)  # [batch_size, seq_len]
        position_embedding = self.position_embedding(positions)  # [batch_size, seq_len, hidden_dim]
        x = x + position_embedding  # 加入位置编码

        # Dropout 应用在嵌入和位置编码之后
        x = self.dropout(x)

        # 转换为 [seq_len, batch_size, hidden_dim] 符合 Transformer 的输入格式
        x = rearrange(x, 'b s d -> s b d')  # [seq_len, batch_size, hidden_dim]

        return self.model(x)[-1]
