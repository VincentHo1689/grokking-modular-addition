# Project Overview

This project investigates the grokking phenomenon in modular arithmetic using various neural network architectures and optimizers. The tasks include reproducing results from a research paper, analyzing the effects of different architectures and optimizers, and exploring the impact of the number of summands on the grokking phenomenon.

## How to Run the Main Program

To run the main program, use the following command:

```bash
python main.py --K <number_of_tokens> --p <modulo_value> --batch_size <batch_size> --alpha <alpha_value> --num_epochs <number_of_epochs> --device <device> --modelType <model_type>
```

Example:

```bash
python main.py --K 2 --p 97 --batch_size 256 --alpha 0.5 --num_epochs 1000 --device cuda:0 --modelType Transformer
```

## Python and Module Versions

- **Python**: 3.11.7
- **Modules**:
  - `torch`: 2.0.1
  - `numpy`: 1.24.2
  - `matplotlib`: 3.7.1
  - `tqdm`: 4.65.0
  - `einops`: 0.6.0
  - `argparse`: 1.4.0
  - `pickle`: 5.0.0

## Setting Up the Environment

To set up the environment with the required packages, use the provided `environment.yml` file. Run the following command:

```bash
conda env create -f environment.yml
```

This will create a conda environment with all the necessary packages installed.

## File Descriptions

### `main.py`

- **Purpose**: Main script to train and evaluate models.
- **Functions**:
  - `main(args)`: Parses arguments, initializes data loaders, models, optimizer, and scheduler, and trains the model.
  - `if __name__ == "__main__":`: Argument parser setup and main function call.

### `data.py`

- **Purpose**: Data collection and splitting.
- **Functions**:
  - `collect_data_mod_p(p, K)`: Generates input data and labels for modular arithmetic.
  - `split_data(p, K, alpha, batch_size)`: Splits data into training and validation sets.

### `model.py`

- **Purpose**: Defines various neural network architectures.
- **Classes**:
  - `DecoderBlock`: Transformer decoder block.
  - `Transformer`: Transformer model.
  - `MLP`: Multi-layer perceptron model.
  - `LSTM`: Long short-term memory model.

### `model_dropout.py`

- **Purpose**: Defines Transformer model with dropout.
- **Classes**:
  - `DecoderBlock`: Transformer decoder block with dropout.
  - `Transformer_dropout`: Transformer model with dropout.

### `train.py`

- **Purpose**: Training and evaluation functions.
- **Functions**:
  - `train(model, train_loader, optimizer, scheduler, device, epoch)`: Trains the model for one epoch.
  - `evaluate(model, val_loader, device, epoch)`: Evaluates the model on the validation set.

### `util.py`

- **Purpose**: Utility functions.
- **Functions**:
  - `plot(train_accuracies, val_accuracies, num_epochs, save_path)`: Plots training and validation accuracies.

### `ML-Subtask3-final.ipynb`

- **Purpose**: Jupyter notebook for Subtask 3, analyzing the effects of different optimizers and regularization techniques on the grokking phenomenon.

## Additional Information

- Ensure you have a GPU available and set the `--device` argument to `cuda:0` or `cuda:1` accordingly.
- The `ML-Subtask3-final.ipynb` notebook is used for analyzing different optimizers and regularization techniques. Ensure to run this notebook separately to reproduce the results for Subtask 3.
- Create necessary directories (`./figures` and `output`) before running the scripts to avoid any file saving issues.
