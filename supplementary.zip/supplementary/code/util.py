import matplotlib.pyplot as plt

def plot(train_accuracies, val_accuracies, num_epochs, save_path):
    plt.figure(figsize=(10, 6))
    plt.plot(range(num_epochs), train_accuracies, label='Training Accuracy', color='b')
    plt.plot(range(num_epochs), val_accuracies, label='Validation Accuracy', color='g')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.title('Training and Validation Accuracy over Epochs')
    plt.legend()
    plt.grid(True)
    plt.savefig(save_path)  # Save the plot as a PNG file
    
def log_plot(train_accuracies, val_accuracies, num_epochs, save_path):
    plt.figure(figsize=(10, 6))
    plt.plot(range(1, num_epochs + 1), train_accuracies, label='Training Accuracy', color='b')
    plt.plot(range(1, num_epochs + 1), val_accuracies, label='Validation Accuracy', color='g')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.title('Training and Validation Accuracy over Epochs')
    plt.xscale('log')  # 设置 x 轴为对数刻度
    plt.legend()
    plt.grid(True, which="both", linestyle='--', linewidth=0.5)  # 添加网格线，显示主刻度和次刻度
    plt.savefig(save_path)  # 保存图像