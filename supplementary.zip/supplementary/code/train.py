import torch

def train(model, train_loader, optimizer, scheduler, device, epoch):
    # Set model to training mode
    model.train()
    criterion = torch.nn.CrossEntropyLoss()
    total_loss = 0.0
    total_acc = 0.0
    total = len(train_loader.dataset)
    
    # Loop over each batch from the training set
    for batch in train_loader:
        inputs, labels = batch
        inputs, labels = inputs.to(device), labels.to(device)

        # Zero gradient buffers
        optimizer.zero_grad()
        
        # Forward pass
        output = model(inputs)
        loss = criterion(output, labels)
        acc = (torch.argmax(output, dim=1) == labels).sum()
        
        # Backward pass
        loss.backward()
        total_loss += loss.item()
        total_acc += acc.item()

        # Update weights
        optimizer.step()
        scheduler.step()
    
    # Calculate the average loss and accuracy for the epoch
    avg_loss = total_loss / total
    avg_acc = total_acc / total

    return avg_acc

def evaluate(model, val_loader, device, epoch):
    model.eval()
    criterion = torch.nn.CrossEntropyLoss()
    total_loss = 0.0
    total_acc = 0.0
    total = len(val_loader.dataset)

    with torch.no_grad():
        for batch in val_loader:
            inputs, labels = batch
            inputs, labels = inputs.to(device), labels.to(device)
            
            # Forward pass
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            acc = (torch.argmax(outputs, dim=1) == labels).sum()
            
            total_loss += loss.item()
            total_acc += acc.item()
        
        val_loss = total_loss / total
        val_acc = total_acc / total
    
    return val_acc