import torch
"""
从train_loader中返回的数据shape = [batch_size, K, p]
从val_loader中返回的数据shape = [batch_size, p]
"""
def collect_data_mod_p(p, K):
    """p is the mod prime"""
    """K is the number of summands"""
    # 创建一个包含 K 个范围 [0, p - 1] 的列表
    ranges = [torch.arange(0, p) for _ in range(K)]
    
    # 计算 K 维笛卡尔积
    cartesian_prod = torch.cartesian_prod(*ranges)
    pK = cartesian_prod.shape[0]
    
    # 创建一个空的输入张量，形状为 (p^K, K, p)
    inputs = torch.zeros((pK, K, p), dtype=torch.float32)
    
    # 将每个笛卡尔积组合的每个元素编码为 one-hot 向量
    for i, comb in enumerate(cartesian_prod):
        for j, val in enumerate(comb):
            inputs[i, j, val] = 1  # 将对应的索引位置设置为 1
    
    # 计算 labels，每个标签是 K 个维度的和 mod p
    labels = torch.zeros((pK,), dtype=torch.int64)
    for i, comb in enumerate(cartesian_prod):
        # 计算每个组合的 K 个维度的和，并取 mod p
        labels[i] = comb.sum() % p
    
    return inputs, labels

def split_data(p, K, alpha, batch_size = 32):
    """p is the mod prime"""
    """K is the number of summands"""
    """alpha is the training data fraction"""
    inputs, labels = collect_data_mod_p(p, K)
    dataset = torch.utils.data.TensorDataset(inputs, labels)
    train_size = int(alpha * len(dataset))
    val_size = len(dataset) - train_size
    train_dataset, val_dataset = torch.utils.data.random_split(dataset, [train_size, val_size])
    
    train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=batch_size, shuffle=True)

    return train_loader, val_loader