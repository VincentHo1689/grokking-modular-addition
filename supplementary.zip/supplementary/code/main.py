import argparse
import torch
import random
from tqdm import tqdm
from math import ceil
from data import split_data
from model import Transformer, MLP, LSTM
from model_dropout import Transformer_dropout
from train import train, evaluate
from util import plot, log_plot

def set_seed(seed):
    random.seed(seed)  # 设置 Python 的随机种子
    torch.manual_seed(seed)  # 设置 PyTorch 的 CPU 随机种子
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)  # 设置 PyTorch 的 GPU 随机种子
        torch.cuda.manual_seed_all(seed)  # 如果有多个 GPU，也为所有 GPU 设置种子
        torch.backends.cudnn.deterministic = True  # 确保 CUDA 使用确定性的结果
        torch.backends.cudnn.benchmark = False  # 禁用 CUDNN 自动优化

def main(args):
    K = args.K
    p = args.p
    batch_size = args.batch_size
    alpha = args.alpha
    num_epochs = args.num_epochs
    device = args.device
    modelType = args.modelType
    dropout = args.dropout
    
    """使用种子"""
    #seed = random.randint(0, 100)
    seed = 36
    set_seed(seed)
    
    save_path = f"./figures/acc_p={p}_K={K}_alpha={alpha}_epoch={num_epochs}_seed={seed}_b={batch_size}.png"
    
    train_loader, val_loader = split_data(
        p = p, 
        K = K, 
        alpha = alpha, 
        batch_size = batch_size,
    )
    
    if modelType == "MLP":
        model = MLP(
            input_dim = K * p,
            hidden_dim1 = 256, 
            hidden_dim2 = 128, 
            output_dim = p,
        )
    elif modelType == "Transformer":
        if dropout <= 0:
            model = Transformer(
                input_dim = p, 
                hidden_dim = 128, 
                num_heads = 4, 
                num_layers = 2, 
                output_dim = p,
                seq_len = K,
            )
        else:
            model = Transformer_dropout(
                input_dim = p, 
                hidden_dim = 128, 
                num_heads = 4, 
                num_layers = 2, 
                output_dim = p,
                seq_len = K,
                dropout = dropout,
            )
    elif modelType == "LSTM":
        model = LSTM(
            input_dim = p, 
            hidden_dim = 128, 
            num_layers = 2, 
            output_dim = p,
            seq_len = K,
        )
    else:
        raise NotImplementedError(f"Model type '{modelType}' is not implemented.")
        
    model = model.to(device)
    
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr = 1e-3,
        betas = (0.9, 0.99),
        weight_decay = 0.005,  # 0.005
    )
    scheduler = torch.optim.lr_scheduler.LinearLR(
        optimizer, start_factor = 0.1, end_factor=1.0, total_iters = 10
    )

    train_accuracies = []  # List to store training accuracies
    val_accuracies = []    # List to store validation accuracies

    for epoch in tqdm(range(num_epochs)):
        train_acc = train(model, train_loader, optimizer, scheduler, device, epoch)
        val_acc = evaluate(model, val_loader, device, epoch)
        train_accuracies.append(train_acc)
        val_accuracies.append(val_acc)
    
    log_plot(train_accuracies, val_accuracies, num_epochs, save_path)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train a model for modular arithmetic.")

    # 参数列表
    parser.add_argument("--K", type=int, default=2, help="Number of tokens in sequence.")
    parser.add_argument("--p", type=int, default=97, help="Modulo value for arithmetic.")
    parser.add_argument("--batch_size", type=int, default=256, help="Batch size.")
    parser.add_argument("--alpha", type=float, default=0.5, help="Alpha value for data splitting.")
    parser.add_argument("--num_epochs", type=int, default=1000, help="Number of epochs.")
    parser.add_argument("--device", type=str, default='cuda:0' if torch.cuda.is_available() else 'cpu',
                        help="Device to train on ('cpu' or 'cuda').")
    parser.add_argument("--modelType", type=str, default="Transformer", choices=["MLP", "Transformer", "LSTM"],
                        help="Type of model to use.")
    parser.add_argument("--dropout", type=float, default=0.0, help="Dropout rate of Transformer.")

    # 解析参数
    args = parser.parse_args()

    # 传递参数到 main 函数
    main(args)