import torch
import torch.nn as nn
from torch import Tensor
from einops import repeat, rearrange

class DecoderBlock(torch.nn.Module):
    def __init__(self, dim_model: int, n_heads: int):
        super().__init__()

        self.self_attn = nn.MultiheadAttention(dim_model, n_heads)
        self.self_attn_norm = nn.LayerNorm(dim_model)
        self.ffn = nn.Sequential(
            nn.Linear(dim_model, dim_model * 4),
            nn.GELU(),
            nn.Linear(dim_model * 4, dim_model)
        )
        self.ffn_norm = nn.LayerNorm(dim_model)

    def forward(self, x: Tensor):
        attn_mask = torch.full(
            (len(x), len(x)), -float("Inf"), device=x.device, dtype=x.dtype
        )
        attn_mask = torch.triu(attn_mask, diagonal=1)

        a1, _ = self.self_attn(x, x, x, attn_mask=attn_mask)
        a1 = self.self_attn_norm (x + a1)
        a2 = self.ffn(a1)
        a2 = self.ffn_norm(a1 + a2)

        return a2

class Transformer(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_heads, num_layers, output_dim, seq_len):
        super(Transformer, self).__init__()
        
        # 输入嵌入层：将每个 one-hot 向量映射到指定维度
        self.embedding = nn.Linear(input_dim, hidden_dim)
        
        # 使用 nn.Embedding 实现可学习的位置编码
        self.position_embedding = nn.Embedding(seq_len, hidden_dim)
        
        self.model = nn.Sequential(
            *[DecoderBlock(hidden_dim, num_heads) for _ in range(num_layers)],
            nn.LayerNorm(hidden_dim),
            nn.Linear(hidden_dim, output_dim)
        )
    
    def forward(self, x):
        # x: [batch_size, seq_len, p]
        # seq_len = K
        batch_size, seq_len, p = x.shape

        # 嵌入层
        x = self.embedding(x)  # [batch_size, seq_len, hidden_dim]

        # 添加位置编码
        positions = repeat(torch.arange(seq_len, device=x.device), "p -> b p", b=batch_size)  # [batch_size, seq_len]
        position_embedding = self.position_embedding(positions)  # [batch_size, seq_len, hidden_dim]
        x = x + position_embedding  # 加入位置编码

        # 转换为 [seq_len, batch_size, hidden_dim] 符合 Transformer 的输入格式
        x = rearrange(x, 'b s d -> s b d')  # [seq_len, batch_size, hidden_dim]

        return self.model(x)[-1]
    

class MLP(nn.Module):
    def __init__(self, input_dim, hidden_dim1, hidden_dim2, output_dim):
        super(MLP, self).__init__()
        # 第一层
        self.fc1 = nn.Linear(input_dim, hidden_dim1)
        self.relu1 = nn.ReLU()
        
        # 第二层
        self.fc2 = nn.Linear(hidden_dim1, hidden_dim2)
        self.relu2 = nn.ReLU()
        
        # 输出层
        self.fc3 = nn.Linear(hidden_dim2, output_dim)
        
    def forward(self, x):
        # Flattening the input from [batch_size, K, p] to [batch_size, K*p]
        x = x.view(x.size(0), -1)  # Shape [batch_size, K*p]
        
        x = self.fc1(x)
        x = self.relu1(x)
        
        x = self.fc2(x)
        x = self.relu2(x)
        
        x = self.fc3(x)
        return x
        

class LSTM(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_layers, output_dim, seq_len):
        super(LSTM, self).__init__()

        # 输入嵌入层：将每个 one-hot 向量映射到指定维度
        self.embedding = nn.Linear(input_dim, hidden_dim)

        # 使用 nn.Embedding 实现可学习的位置编码
        self.position_embedding = nn.Embedding(seq_len, hidden_dim)

        # LSTM 模块
        self.lstm = nn.LSTM(
            input_size=hidden_dim,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            batch_first=True  # 保证输入输出的形状为 [batch_size, seq_len, hidden_dim]
        )

        # 输出层：将 LSTM 的隐藏状态映射到输出维度
        self.fc_out = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        # x: [batch_size, seq_len, p]
        # seq_len = K
        batch_size, seq_len, p = x.shape

        # 嵌入层
        x = self.embedding(x)  # [batch_size, seq_len, hidden_dim]

        # 添加位置编码
        positions = repeat(torch.arange(seq_len, device=x.device), "p -> b p", b=batch_size)  # [batch_size, seq_len]
        position_embedding = self.position_embedding(positions)  # [batch_size, seq_len, hidden_dim]
        x = x + position_embedding  # 加入位置编码

        # LSTM 模块
        x, (hn, cn) = self.lstm(x)  # x: [batch_size, seq_len, hidden_dim], hn: [num_layers, batch_size, hidden_dim]

        # 获取最后一个时间步的输出
        x = x[:, -1, :]  # [batch_size, hidden_dim]

        # 输出层
        x = self.fc_out(x)  # [batch_size, output_dim]

        return x